import React from "react";
const Contact = () => { 

    return (
        <div>
            <h1>User Management</h1>
            <p>This is the user management page.</p>
        </div>
    );
};

export default Contact;
            
    
