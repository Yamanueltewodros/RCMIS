import React from "react";
import "../../Styling/AdminPageStyles/ProfessionalManagementStyles/ProfessionalReport.css";

const ProfessionalReports = () => {
  return (
    <div className="reports-container">
      <h2>Professional Reports</h2>
      <p>This section will display the reports for professionals.</p>
      {/* You can add more content such as tables, charts, or any other report data here */}
    </div>

  );
};

export default ProfessionalReports;
