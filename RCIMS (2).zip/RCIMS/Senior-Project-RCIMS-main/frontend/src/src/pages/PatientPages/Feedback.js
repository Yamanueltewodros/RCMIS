const Feedback = () =>{
    return (
        <>
        <h1>Appointment</h1>
        </>
    );
}

export default Feedback;