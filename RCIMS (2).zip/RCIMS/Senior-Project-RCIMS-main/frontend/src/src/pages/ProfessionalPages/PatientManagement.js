import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"; // Ensure React Router DOM is properly configured
import ViewPatient from "./ViewPatient";
import AddPatientHistory from "./AddPatientHistory";
import axios from "axios";

import "./ProfessionalStyles/PatientManagement.css";
const PatientManagement = () => {
  const [activeTab, setActiveTab] = useState("ListOfPatients");
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState({ patientType: "", employmentStatus: "" });
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null); // Track selected patient
  const navigate = useNavigate(); // To programmatically navigate between routes

  // Fetch patients with search and filter options
  const fetchFilteredPatients = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/patients/get-patients", {
        params: {
          search: searchTerm,
          patientType: filter.patientType,
          employmentStatus: filter.employmentStatus,
        },
      });
      setFilteredPatients(response.data.patients || []);
    } catch (error) {
      console.error("Error fetching filtered patients:", error);
    }
  };

  // Update filtered patients whenever search/filter changes
  useEffect(() => {
    if (activeTab === "ListOfPatients") {
      fetchFilteredPatients();
    }
  }, [searchTerm, filter, activeTab]);

  // Handle click for viewing patient's history or details
  const handleViewPatient = (patientId) => {
    setSelectedPatient(patientId);
    setActiveTab("ViewPatient");
  };

  // Handle click for adding patient history
  const handleAddHistory = (patientId) => {
    setSelectedPatient(patientId);
    setActiveTab("AddPatientHistory");
    navigate(`/add-history/${patientId}`); // Programmatic navigation to history page
  };

  // Function to render the correct component based on the active tab
  const renderActiveTab = () => {
    switch (activeTab) {
      case "ListOfPatients":
        return (
          <ListOfPatients
            patients={filteredPatients}
            onViewPatient={handleViewPatient}
            onAddHistory={handleAddHistory}
          />
        );
      case "ViewPatient":
        return <ViewPatient patientId={filteredPatients} />;
      case "AddPatientHistory":
        return <AddPatientHistory patientId={selectedPatient} />;
      default:
        return <ListOfPatients patients={filteredPatients} />;
    }
  };

  return (
    <div className="patient-management-page">
      {/* Navigation tabs */}
      <div className="tabs">
        <button
          className={`tab-button ${activeTab === "ListOfPatients" ? "active" : ""}`}
          onClick={() => setActiveTab("ListOfPatients")}
        >
          View All Patients
        </button>
        <button
          className={`tab-button ${activeTab === "AddPatientHistory" ? "active" : ""}`}
          disabled={!selectedPatient}
          onClick={() => handleAddHistory(selectedPatient)} // Ensure this triggers navigation
        >
          Add Patient History
        </button>
      </div>

      {/* Render the component based on the active tab */}
      <div className="tab-content">{renderActiveTab()}</div>
    </div>
  );
};

// ListOfPatients Component
const ListOfPatients = ({ patients, onViewPatient, onAddHistory }) => {
  return (
    <div>
      <h2>List of Patients</h2>
      {patients.length > 0 ? (
        <ul className="patients-list">
          {patients.map((patient) => (
            <li key={patient._id} className="patient-item">
              <div className="patient-info">
                <h3>{`${patient.user?.name} ${patient.user?.fatherName} ${patient.user?.grandfatherName}`}</h3>
                <p><strong>Phone Number:</strong> {patient.user?.phoneNumber}</p>
                <p><strong>Patient Type:</strong> {patient.patientType}</p>
              </div>
              <div className="patient-actions">
                <button className="btn btn-details" onClick={() => onViewPatient(patient._id)}>View Details</button>
                <button className="btn btn-add-history" onClick={() => onAddHistory(patient._id)}>Add History</button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p>No patients found.</p>
      )}
    </div>
  );
};

export default PatientManagement;
