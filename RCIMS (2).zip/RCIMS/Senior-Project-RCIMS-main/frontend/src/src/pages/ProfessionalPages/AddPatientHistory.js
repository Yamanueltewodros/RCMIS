import React, { useState } from "react";
import axios from "axios";
import "./ProfessionalStyles/AddPatientHistory.css"
const AddPatientHistory = ({ patientId }) => {
  const [formData, setFormData] = useState({
    medicalCondition: "",
    substanceUseHistory: "",
    medications: "",
    allergies: "",
    traumaHistory: "",
    additionalNotes: ""
  });

  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        `http://localhost:5000/api/patients/${patientId}/add-history`,
        formData
      );
      if (response.status === 200) {
        setSuccess("Patient history added successfully!");
        setFormData({
          medicalCondition: "",
          substanceUseHistory: "",
          medications: "",
          allergies: "",
          traumaHistory: "",
          additionalNotes: ""
        });
      }
    } catch (error) {
      setError("Error adding patient history. Please try again.");
      console.error(error);
    }
  };

  return (
    <div className="add-patient-history">
      <h2>Add Patient History</h2>
      {error && <p className="error">{error}</p>}
      {success && <p className="success">{success}</p>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="medicalCondition">Medical Condition</label>
          <input
            type="text"
            id="medicalCondition"
            name="medicalCondition"
            value={formData.medicalCondition}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="substanceUseHistory">Substance Use History</label>
          <input
            type="text"
            id="substanceUseHistory"
            name="substanceUseHistory"
            value={formData.substanceUseHistory}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="medications">Medications</label>
          <input
            type="text"
            id="medications"
            name="medications"
            value={formData.medications}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="allergies">Allergies</label>
          <input
            type="text"
            id="allergies"
            name="allergies"
            value={formData.allergies}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="traumaHistory">Trauma History</label>
          <input
            type="text"
            id="traumaHistory"
            name="traumaHistory"
            value={formData.traumaHistory}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="additionalNotes">Additional Notes</label>
          <textarea
            id="additionalNotes"
            name="additionalNotes"
            value={formData.additionalNotes}
            onChange={handleChange}
          />
        </div>

        <button type="submit" className="submit-btn">
          Submit
        </button>
      </form>
    </div>
  );
};

export default AddPatientHistory;
