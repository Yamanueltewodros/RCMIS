import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ProfessionalStyles/AttachPatient.css";


const AttachPatient = () => {
    const [professionals, setProfessionals] = useState([]);
    const [patients, setPatients] = useState([]);
    const [selectedProfessional, setSelectedProfessional] = useState("");
    const [selectedPatient, setSelectedPatient] = useState("");
    const [department, setDepartment] = useState("");
    const [message, setMessage] = useState("");

    // Fetch professionals and patients when the component mounts
    useEffect(() => {
        fetchProfessionals();
        fetchPatients(); // This function assumes an API to get all patients
    }, []);

    const fetchProfessionals = async () => {
        try {
            const response = await axios.get("http://localhost:5000/api/professionals/get-professionals");
            setProfessionals(response.data.professionals); // Adjust the key based on your API response
        } catch (error) {
            console.error("Error fetching professionals:", error);
        }
    };

    const fetchPatients = async () => {
        try {
            const response = await axios.get("http://localhost:5000/api/patients/get-all-patients"); // Ensure this API exists
            setPatients(response.data.patients); // Adjust based on your response
        } catch (error) {
            console.error("Error fetching patients:", error);
        }
    };

    const handleAttachPatient = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post("http://localhost:5000/api/professionals/attach-patient", {
                professionalId: selectedProfessional,
                patientId: selectedPatient,
                department,
            });
            setMessage(response.data.message);
        } catch (error) {
            console.error("Error attaching patient:", error);
            setMessage("Failed to attach patient.");
        }
    };

    return (
        <div className="attach-detach-container">
            <h2>Attach Patient to Professional</h2>

            {message && <p>{message}</p>}

            <form onSubmit={handleAttachPatient}>
                <label>Select Professional:</label>
                <select
                    value={selectedProfessional}
                    onChange={(e) => setSelectedProfessional(e.target.value)}
                    required
                >
                    <option value="">-- Select Professional --</option>
                    {professionals.map((professional) => (
                        <option key={professional._id} value={professional._id}>
                            {professional.user.name} ({professional.speciality})
                        </option>
                    ))}
                </select>

                <label>Select Patient:</label>
                <select
                    value={selectedPatient}
                    onChange={(e) => setSelectedPatient(e.target.value)}
                    required
                >
                    <option value="">-- Select Patient --</option>
                    {patients.map((patient) => (
                        <option key={patient._id} value={patient._id}>
                            {patient.name}
                        </option>
                    ))}
                </select>

                <label>Department (Optional):</label>
                <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                />

                <button type="submit">Attach Patient</button>
            </form>
        </div>
    );
};

export default AttachPatient;

